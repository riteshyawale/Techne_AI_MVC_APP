﻿using CRUDAPP.Models;
using Microsoft.EntityFrameworkCore;

namespace CRUDAPP.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
        }

        public DbSet<ItemModel> Category { get; set; }

    }
}