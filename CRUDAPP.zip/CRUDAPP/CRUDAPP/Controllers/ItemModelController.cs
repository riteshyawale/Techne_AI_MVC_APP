﻿using CRUDAPP.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CRUDAPP.Models;
using System.Threading.Tasks;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Data;
using MySqlConnector;
using Microsoft.Extensions.Configuration;
using CRUDAPP.Model;

namespace CRUDAPP.Controllers
{
    public class ItemModelController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly MySqlConnection _connection;
        private readonly IConfiguration _configuration;

        public ItemModelController(ApplicationDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
            _connection = new MySqlConnection(_configuration.GetConnectionString("DefaultConnectionMySQL"));
        }

        public async Task<IActionResult> Index()
        {
            var items = new List<ItemModel>();
            var customers = new List<CustomerModel>(); 

            await _connection.OpenAsync();

            // Fetch items
            using (var cmd = _connection.CreateCommand())
            {
                cmd.CommandText = "GetItemList";
                cmd.CommandType = CommandType.StoredProcedure;

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        var category = new ItemModel
                        {
                            Id = reader.GetInt64("Id"),
                            Name = reader.GetString("Name"),
                            Rate = reader.GetString("Rate")
                        };
                        items.Add(category);
                    }
                }
            }

            // Fetch customers
            using (var cmd = _connection.CreateCommand())
            {
                cmd.CommandText = "GetCustomerList"; 
                cmd.CommandType = CommandType.StoredProcedure;

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        var customer = new CustomerModel
                        {
                            CustId = reader.GetInt64("Id"),
                            CustomerName = reader.GetString("Name"),
                            Address = reader.GetString("Address"),
                            City = reader.GetString("City"),

                        };
                        customers.Add(customer);
                    }
                }
            }

            var viewModel = new CombinedModel
            {
                Items = items,
                Customers = customers
            };

            return View(viewModel);
        }

        [HttpPost]
        public async Task<IActionResult> SaveBill([FromBody] BillModel model)
        {
            if (!ModelState.IsValid)
                return Json(new { success = false, errors = ModelState.Values.SelectMany(v => v.Errors) });

            try
            {
                await using (var connection = _connection)
                {
                    await connection.OpenAsync();

                    using (var cmd = connection.CreateCommand())
                    {
                        cmd.CommandText = "SaveBillHeader";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("ip_Date", model.Date);
                        cmd.Parameters.AddWithValue("ip_BillNo", model.BillNo);
                        cmd.Parameters.AddWithValue("ip_SelectedCustomerId", model.SelectedCustomerId);
                        cmd.Parameters.AddWithValue("ip_Amount", model.TotalAmount);
                        await cmd.ExecuteNonQueryAsync();
                    }

                    foreach (var item in model.Items)
                    {
                        using (var cmd = connection.CreateCommand())
                        {
                            cmd.CommandText = "SaveBillDetails";
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("ip_ItemName", item.Name);
                            cmd.Parameters.AddWithValue("ip_ItemRate", item.Rate);
                            cmd.Parameters.AddWithValue("ip_ItemQty", item.Qty);
                            await cmd.ExecuteNonQueryAsync();
                        }
                    }
                }

                return Json(new { success = true, data = model });
            }
            catch (Exception e)
            {
                return Json(new { success = false, errors = new[] { e.Message } });
            }
        }



        private bool CategoryExists(long id)
        {
          return (_context.Category?.Any(e => e.Id == id)).GetValueOrDefault();
        }

    }
}
