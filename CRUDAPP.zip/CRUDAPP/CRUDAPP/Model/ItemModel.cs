﻿
using System;
using System.ComponentModel.DataAnnotations;

namespace CRUDAPP.Models
{
    public class ItemModel
    {
        public Int64 Id { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string Rate { get; set; }
        
    }
}
