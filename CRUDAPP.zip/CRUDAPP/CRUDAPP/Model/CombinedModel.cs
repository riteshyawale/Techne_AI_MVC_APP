﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRUDAPP.Models
{
    public class CombinedModel
    {
            public List<ItemModel> Items { get; set; }
            public List<CustomerModel> Customers { get; set; } 
    }
}
