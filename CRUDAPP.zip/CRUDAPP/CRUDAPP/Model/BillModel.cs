﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRUDAPP.Model
{
    public class BillModel
    {
        public string Date { get; set; }
        public string BillNo { get; set; }
        public int SelectedCustomerId { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public int TotalAmount { get; set; }
        public List<ItemList> Items { get; set; } 
    }

    public class ItemList
    {
        public string Name { get; set; }
        public int Rate { get; set; }
        public int Qty { get; set; }
        public int Amount { get; set; }
    }
}
