﻿
using System;
using System.ComponentModel.DataAnnotations;

namespace CRUDAPP.Models
{
    public class CustomerModel
    {
        public Int64 CustId { get; set; }
        [Required]
        public string CustomerName { get; set; }
        [Required]
        public string Address { get; set; }
        [Required]
        public string City { get; set; }
        
    }
}